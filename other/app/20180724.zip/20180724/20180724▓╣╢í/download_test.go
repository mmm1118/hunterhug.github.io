/*
	版权所有，侵权必究
	署名-非商业性使用-禁止演绎 4.0 国际
	警告： 以下的代码版权归属hunterhug，请不要传播或修改代码
	你可以在教育用途下使用该代码，但是禁止公司或个人用于商业用途(在未授权情况下不得用于盈利)
	商业授权请联系邮箱：gdccmcm14@live.com QQ:459527502

	All right reserved
	Attribution-NonCommercial-NoDerivatives 4.0 International
	Notice: The following code's copyright by hunterhug, Please do not spread and modify.
	You can use it for education only but can't make profits for any companies and individuals!
	For more information on commercial licensing please contact hunterhug.
	Ask for commercial licensing please contact Mail:gdccmcm14@live.com Or QQ:459527502

	2017.7 by hunterhug
*/
package core

import (
	"fmt"
	"testing"

	"github.com/hunterhug/AmazonBigSpider"
	spider "github.com/hunterhug/marmot/miner"
	"github.com/hunterhug/parrot/util"
)

// https://www.amazon.com/Best-Sellers-Automotive-Performance-ABS-Brake-Parts/zgbs/automotive/15710931/ref=zg_bs_pg_1?_encoding=UTF8&pg=1&ajax=1
// https://www.amazon.com/Best-Sellers-Automotive-Performance-ABS-Brake-Parts/zgbs/automotive/15710931/ref=zg_bs_pg_2?_encoding=UTF8&pg=2&ajax=1
// https://www.amazon.com/Best-Sellers-Automotive-Performance-ABS-Brake-Parts/zgbs/automotive/15710931/ref=zg_bs_pg_3?_encoding=UTF8&pg=3&ajax=1
// https://www.amazon.com/Best-Sellers-Automotive-Performance-ABS-Brake-Parts/zgbs/automotive/15710931/ref=zg_bs_pg_4?_encoding=UTF8&pg=4&ajax=1
// https://www.amazon.com/Best-Sellers-Automotive-Performance-ABS-Brake-Parts/zgbs/automotive/15710931/ref=zg_bs_pg_5?_encoding=UTF8&pg=5&ajax=1
// https://www.amazon.com/dp/B001IHBLPC

// https://www.amazon.com/gp/new-releases/kitchen/1063916/ref=zg_bsnr_pg_3?ie=UTF8&pg=3&ajax=1
func TestAsinDownload(t *testing.T) {
	util.MakeDir(AmazonBigSpider.Dir + "/test/asin/")
	ip := "104.128.124.122:808"
	// debug info will no appear |nothing
	spider.SetLogLevel("info")
	url := "https://www.amazon.com/dp/B016L36UZI"
	prefix := "asin"
	testtimes := 1000
	for {
		testtimes--
		if testtimes == 0 {
			break
		}
		robotime := 0
		maxtime := 1000
		times := 0
		for {
			if times > maxtime {
				break
			}
			temp := url
			content, err := Download(ip, temp)
			if err != nil {
				fmt.Printf("%#v", err.Error())
			} else {
				err = spider.TooSortSizes(content, 10)
				// robot continue
				if err != nil {
					robotime++
					times++
					break
				} else {
					// and then out
					fmt.Printf("The %d try Asin page :%d times | robbot max times:%d\n", testtimes, times, robotime)
				}
				util.SaveToFile(AmazonBigSpider.Dir+"/test/asin/"+prefix+util.IS(testtimes)+".html", content)
				break
			}
		}
	}
}

func TestListDownload(t *testing.T) {
	util.MakeDir(AmazonBigSpider.Dir + "/test/list/")
	ip := "*a"
	// debug info will no appear |nothing
	spider.SetLogLevel("info")
	url := "https://www.amazon.co.jp/gp/bestsellers/dvd/ref=zg_bs_nav_0"
	content, err := Download(ip, url)
	if err != nil {
		fmt.Printf("%#v", err.Error())
		return
	}
	util.SaveToFile(AmazonBigSpider.Dir+"/test/list/jp.html", content)

	url = "https://www.amazon.com/Best-Sellers-Computers-Accessories/zgbs/pc?_encoding=UTF8&pg=1&ajax=1"
	content, err = Download(ip, url)
	if err != nil {
		fmt.Printf("%#v", err.Error())
		return
	}
	util.SaveToFile(AmazonBigSpider.Dir+"/test/list/usa.html", content)

	url = "https://www.amazon.co.uk/Best-Sellers-Business-Industry-Science/zgbs/industrial?_encoding=UTF8&pg=1&ajax=1"
	content, err = Download(ip, url)
	if err != nil {
		fmt.Printf("%#v", err.Error())
		return
	}
	util.SaveToFile(AmazonBigSpider.Dir+"/test/list/uk.html", content)

	url = "https://www.amazon.de/gp/bestsellers/beauty?_encoding=UTF8&pg=1&ajax=1"
	content, err = Download(ip, url)
	if err != nil {
		fmt.Printf("%#v", err.Error())
		return
	}
	util.SaveToFile(AmazonBigSpider.Dir+"/test/list/de.html", content)
}

/*
	版权所有，侵权必究
	署名-非商业性使用-禁止演绎 4.0 国际
	警告： 以下的代码版权归属hunterhug，请不要传播或修改代码
	你可以在教育用途下使用该代码，但是禁止公司或个人用于商业用途(在未授权情况下不得用于盈利)
	商业授权请联系邮箱：gdccmcm14@live.com QQ:459527502

	All right reserved
	Attribution-NonCommercial-NoDerivatives 4.0 International
	Notice: The following code's copyright by hunterhug, Please do not spread and modify.
	You can use it for education only but can't make profits for any companies and individuals!
	For more information on commercial licensing please contact hunterhug.
	Ask for commercial licensing please contact Mail:gdccmcm14@live.com Or QQ:459527502

	2017.7 by hunterhug
*/
